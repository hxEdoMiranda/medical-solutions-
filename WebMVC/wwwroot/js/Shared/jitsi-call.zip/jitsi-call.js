﻿import { getJwtCall } from '../apis/jitsi-fetch.js?1';


(async function () {
	debugger
		const idAtencion = document.querySelector('[name="Atencion.Id"]').value;
		var jwtCall = await getJwtCall(parseInt(idAtencion), uid)
		const api = new JitsiMeetExternalAPI("8x8.vc", {
			roomName: jwtCall.roomName,
			parentNode: document.querySelector('#videoJitsi'),
			jwt: jwtCall.token,
			interfaceConfigOverwrite: {  LANG_DETECTION: false,  },
			configOverwrite: {
				startWithAudioMuted: false,
				startWithVideoMuted: false,
				enableWelcomePage: false,
				prejoinPageEnabled: false,
				readOnlyName: true,
				defaultLanguage: 'es',
				toolbarButtons: [
                    'camera',
                    //'chat',
                    'closedcaptions',
                    'desktop',
                    'download',
                    'embedmeeting',
                    'etherpad',
                    //'feedback',
                    'filmstrip',
                    'fullscreen',
                    'hangup',
                    'help',
                    //'invite',
                    'livestreaming',
                    'microphone',
                    'mute-everyone',
                    'mute-video-everyone',
                    //'participants-pane',
                    'profile',
                    'raisehand',
                    'recording',
                    //'security',
                    'select-background',
                    'settings',
                    //'shareaudio',
                    //'sharedvideo',
                    //'shortcuts',
                    'stats',
                    'tileview',
                    'toggle-camera',
                    'videoquality',
                    '__end'
				],

			},
		});
	
})();
